﻿#include <iostream>
#include <conio.h>

using namespace std;

int main(int argc, char *argv[])
{
    if (argc != 2)
        return 1;

    int i;
    cout << "Hello " << argv[1] << "!" << endl;
    cout << "Enter 0 to successfully exit and other to unsuccessful: ";
    cin >> i;
    return i;
}
