﻿#include <iostream>
using namespace std;

int fun(int& x) { return x; }

int main()
{
    // cout << fun(10); // error
    return 0;
}

/*
./3337ee98-ae6e-4792-8128-7c879288221f.cpp: In function 'int main()':
./3337ee98-ae6e-4792-8128-7c879288221f.cpp:8:19: error: invalid initialization of non-const reference of type 'int&' from an rvalue of type 'int'
     cout << fun(10);
                   ^
./3337ee98-ae6e-4792-8128-7c879288221f.cpp:4:5: note: in passing argument 1 of 'int fun(int&)'
 int fun(int& x) { return x; }
 */
