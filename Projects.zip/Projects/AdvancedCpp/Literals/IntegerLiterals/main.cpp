#include <iostream>

using namespace std;

int main()
{
    // constant integer literal
    const int intVal = 10;
    cout << "Integer Literal: "
         << intVal << "\n";

    return 0;
}
