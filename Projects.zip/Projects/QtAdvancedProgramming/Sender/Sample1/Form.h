﻿#ifndef FORM_H
#define FORM_H

#include <QWidget>

class Form : public QWidget
{
    Q_OBJECT

public:
    Form(const QStringList &texts, QWidget *parent = nullptr);

private slots:
    void clicked(bool checked = false);
};

#endif // FORM_H
