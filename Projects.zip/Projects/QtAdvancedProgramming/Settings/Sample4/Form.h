﻿#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QSettings>

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

signals:

private:
    QSettings settings;

    void writeSettings();
    void readSettings();
};

#endif // FORM_H
