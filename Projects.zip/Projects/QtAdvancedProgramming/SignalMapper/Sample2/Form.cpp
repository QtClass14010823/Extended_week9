﻿#include "Form.h"

#include <QGridLayout>
#include <QPushButton>
#include <QMessageBox>

Form::Form(const QStringList &texts, QWidget *parent)
    : QWidget(parent)
{
    signalMapper = new QSignalMapper(this);

    QGridLayout *gridLayout = new QGridLayout(this);

    for (int i = 0; i < texts.size(); ++i)
    {
        QPushButton *button = new QPushButton(texts[i]);
        //connect(button, SIGNAL(clicked()), signalMapper, SLOT(map()));
        connect(button, &QPushButton::clicked, signalMapper, QOverload<>::of(&QSignalMapper::map));

        signalMapper->setMapping(button, i);
        gridLayout->addWidget(button, i / 3, i % 3);
    }

    connect(signalMapper, &QSignalMapper::mappedInt,
            this, &Form::clicked);
}

void Form::clicked(int id)
{
    QMessageBox::information(this, "information", QString::number(id));
}
