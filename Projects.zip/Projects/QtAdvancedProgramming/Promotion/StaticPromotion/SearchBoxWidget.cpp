﻿#include "SearchBoxWidget.h"

SearchBoxWidget::SearchBoxWidget(QWidget *parent) : QWidget(parent)
{
    hlay = new QHBoxLayout(this);
    lnEditSearch = new QLineEdit;
    btnSearch = new QPushButton("Search");

    btnSearch->setEnabled(false);
    hlay->addWidget(lnEditSearch);
    hlay->addWidget(btnSearch);

    connect(lnEditSearch, &QLineEdit::textChanged, this, &SearchBoxWidget::on_lnEditSearch_textChanged);
    connect(btnSearch, &QPushButton::clicked, this, &SearchBoxWidget::on_btnSearch_Clicked);
}

void SearchBoxWidget::on_lnEditSearch_textChanged(const QString &text)
{
    btnSearch->setEnabled(!text.isEmpty());
}

void SearchBoxWidget::on_btnSearch_Clicked(bool checked/* = false*/)
{
    emit onSearch(lnEditSearch->text());
}
