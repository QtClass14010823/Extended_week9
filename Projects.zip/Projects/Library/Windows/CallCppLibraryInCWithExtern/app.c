#include <windows.h>
#include <stdio.h>

/*Example of Explicit Call*/
typedef int (add_proc)(int a, int b);

int main(int argc, char *argv[])
{
    add_proc *add;
    HINSTANCE h_dll;
    int a = 1, b = 2, c;
    h_dll = LoadLibrary("mathlib.dll");/*Explicit Load*/
    if(h_dll)
    {
        printf("LoadLibrary returns %x\n", (unsigned int)h_dll);
        add = (add_proc *)GetProcAddress(h_dll, "add");
        if(add)
        {
            printf("GetProcAddress returns add = %x\n", (unsigned int)add);
            c = add(a, b); /*Explicit Call*/
            printf("add %d + %d = %d\n", a, b, c);
        }
        else
        {
            printf("add() not found in mathlib.dll");
        }
        FreeLibrary(h_dll);
    }
    else
    {
        printf("Unable to load mathlib.dll");
        return(-1);
    }
    return 0;
}