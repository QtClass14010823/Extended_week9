// CPP Program to demonstrate Extern "C"

extern "C" {
int printf(const char* format, ...);
}

int printf(const char* format, ...);

// Driver Code
int main()
{
    printf("Hello World.\n");
    return 0;
}
