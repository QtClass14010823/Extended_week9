#include <iostream>

using namespace std;

class base
{
public:
    virtual void car()
    {
        cout<<"base";
    }
};

class derived:public base
{
public:
    void gun()
    {
        cout<<"derived"<<endl;
    }
};

// The bellow code will show an error as base class pointer is
// getting assigned to the derived class pointer (downcasting).
// To make downcasting possible in C++, we need to rewrite the code using dynamic_cast.

//int main()
//{
//    base *b = new derived;
//    derived *d;
//    d=b;        //base class pointer assigned to the derived class pointer
//    d->gun();
//}

int main()
{
    base *b = new derived;
    derived *d;
    d=dynamic_cast<derived*>(b);      //to promote downcasting
    cout<<d<<"\n";
    d->gun();
}
