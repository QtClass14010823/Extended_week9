﻿#include "AppManager.h"
#include <QTimer>
#include <QRandomGenerator>

AppManager::AppManager(QObject *parent) : QObject(parent)
{
}

QString AppManager::performOperationSync(float i, float j)
{
    return QString::number(i + j);
}

void AppManager::performOperationAsync()
{
    QTimer *timer = new QTimer(this);
    timer->setSingleShot(true);
    connect(timer, &QTimer::timeout, this, [this]() {
        const int result = QRandomGenerator::global()->generate();
        const QString &operationResult = result % 2 == 0
                ? "success"
                : "error";
        emit operationFinished(operationResult);
    });
    timer->start(5000);
}
