﻿
#ifndef APPMANAGER_H
#define APPMANAGER_H

#include <QObject>

class AppManager : public QObject
{
    Q_OBJECT

public:
    explicit AppManager(QObject *parent = nullptr);

/*
public slots:
    QString performOperationSync(float i, float j);
    void performOperationAsync();
*/
Q_INVOKABLE QString performOperationSync(float i, float j);
Q_INVOKABLE void performOperationAsync();

signals:
    void operationFinished(const QString &operationResult);
};

#endif // APPMANAGER_H
