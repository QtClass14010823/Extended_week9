#include <unistd.h>

int main(void)
{
    while(1) {
        /* TODO: do something usefull here ;-) */
        printf("Hello!\n");
        sleep(1);
    }
}
