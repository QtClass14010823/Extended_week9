// C++ Program to Creating
// Multiple processes
// Using a fork
#include <iostream>
#include <unistd.h>
using namespace std;

int main()
{
    fork();
    fork();
    cout << "Hello" << endl;

    return 0;
}
